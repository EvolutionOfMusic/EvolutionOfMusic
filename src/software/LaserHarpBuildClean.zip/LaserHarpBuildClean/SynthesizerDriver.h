/*
 *  Created on: 2015-03-07
 *      Author: eorodrig
 */

#ifndef SYNTHESIZERDRIVER_H_
#define SYNTHESIZERDRIVER_H_

void turnOffVoice(int noteNum);
void turnOnVoice(int noteNum);
void sendNoteSynthesizer(int noteNum,int noteType);

#endif /* SYNTHESIZERDRIVER_H_ */
