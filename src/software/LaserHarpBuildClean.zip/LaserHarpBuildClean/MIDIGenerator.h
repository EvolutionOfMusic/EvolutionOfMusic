/*
 * MIDIGenerator.h
 *
 *  Created on: 2015-04-03
 *      Author: qsjiang
 */

#ifndef MIDIGENERATOR_H_
#define MIDIGENERATOR_H_

int getPitch();
int generateMidiData(int pitch,int noteType);
#endif /* MIDIGENERATOR_H_ */
