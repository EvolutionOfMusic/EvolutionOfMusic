This synthesizer was originally implemented and used for the University of Alberta Winter 2015 Computer Engineering
Capstone project. The project this code came from was the laser harp, made by ... .
This synthesizer was modified by Jonathan Peard, Aaron Schuman and Stephen Andersen for use in the University of Alberta 
Winter 2015 Computer Engineering Capstone project. 
The code was modified to be used as the audio synthesizer for an AI music-composing algorithm.