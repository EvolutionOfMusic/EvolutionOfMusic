# Nancy Minderman
# nancy.minderman@ualberta.ca
# November 2015
# Use this script to launch Modelsim altera version

export LM_LICENSE_FILE=12000@lic.ece.ualberta.ca

MODELSIM=/OPT/altera/12.1/tools/modelsim_ae/bin/vsim

$MODELSIM -gui &
