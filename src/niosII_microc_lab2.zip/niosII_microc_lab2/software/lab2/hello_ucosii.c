/*************************************************************************
* Copyright (c) 2004 Altera Corporation, San Jose, California, USA.      *
* All rights reserved. All use of this software and documentation is     *
* subject to the License Agreement located at the end of this file below.*
**************************************************************************
* Description:                                                           *
* The following is a simple hello world program running MicroC/OS-II.The * 
* purpose of the design is to be a very simple application that just     *
* demonstrates MicroC/OS-II running on NIOS II.The design doesn't account*
* for issues such as checking system call return codes. etc.             *
*                                                                        *
* Requirements:                                                          *
*   -Supported Example Hardware Platforms                                *
*     Standard                                                           *
*     Full Featured                                                      *
*     Low Cost                                                           *
*   -Supported Development Boards                                        *
*     Nios II Development Board, Stratix II Edition                      *
*     Nios Development Board, Stratix Professional Edition               *
*     Nios Development Board, Stratix Edition                            *
*     Nios Development Board, Cyclone Edition                            *
*   -System Library Settings                                             *
*     RTOS Type - MicroC/OS-II                                           *
*     Periodic System Timer                                              *
*   -Know Issues                                                         *
*     If this design is run on the ISS, terminal output will take several*
*     minutes per iteration.                                             *
**************************************************************************/


#include <stdio.h>
#include "includes.h"
#include "altera_up_avalon_character_lcd.h"
#include <string.h>
#include "system.h"
#include <ucos_ii.h>
#include <altera_avalon_timer_regs.h>

/* Definition of Task Stacks */
#define   TASK_STACKSIZE       2048
OS_STK    task1_stk[TASK_STACKSIZE];
OS_STK    task2_stk[TASK_STACKSIZE];

/* Definition of Task Priorities */

#define TASK1_PRIORITY      1
#define TASK2_PRIORITY      2

OS_EVENT *IRQ_wait;

void lcdTask(void * pdata);

void lcdTask(void * pdata){
  char counterText[17];
  counterText[16] = '\0';
  int ticksPerSecond,  oldCounter = 0, newCounter;
  INT8U err = OS_NO_ERR;


  alt_up_character_lcd_dev * theLCD = alt_up_character_lcd_open_dev(CHARACTER_LCD_0_NAME);

	while(1){
	  OSSemPend(IRQ_wait,0,&err);
	  newCounter = *(int *) FREQUENCYCOUNTER_0_BASE;
		alt_up_character_lcd_init(theLCD);
		alt_up_character_lcd_set_cursor_pos(theLCD,0,0);
	  ticksPerSecond = newCounter - oldCounter;
	  oldCounter = newCounter;
	  sprintf(counterText,"%i",ticksPerSecond);
	  alt_up_character_lcd_write(theLCD,counterText,strlen(counterText));
	}
}

static void interrupt_isr_gate( void * context) {
	int * IRQ_Stop_address = GATE_TIMER_BASE;
	*IRQ_Stop_address= *IRQ_Stop_address&&0xFE;
	OSSemPost(IRQ_wait);

}



/*Displays the frequency of the given input square wave*/
int main(void)
{
  alt_up_character_lcd_dev * theLCD = alt_up_character_lcd_open_dev(CHARACTER_LCD_0_NAME);

  int * IRQ_address = GATE_TIMER_BASE + ALTERA_AVALON_TIMER_CONTROL_REG;
  *IRQ_address = *IRQ_address||ALTERA_AVALON_TIMER_CONTROL_ITO_MSK;

  IRQ_wait = OSSemCreate(0);


  OSTaskCreateExt(lcdTask,
                  NULL,
                  (void *)&task1_stk[TASK_STACKSIZE-1],
                  TASK1_PRIORITY,
                  TASK1_PRIORITY,
                  task1_stk,
                  TASK_STACKSIZE,
                  NULL,
                  0);
              
  alt_ic_isr_register(GATE_TIMER_IRQ_INTERRUPT_CONTROLLER_ID, GATE_TIMER_IRQ, interrupt_isr_gate, NULL, NULL);

  OSStart();
  return 0;
}



/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2004 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
* Altera does not recommend, suggest or require that this reference design    *
* file be used in conjunction or combination with any other product.          *
******************************************************************************/
