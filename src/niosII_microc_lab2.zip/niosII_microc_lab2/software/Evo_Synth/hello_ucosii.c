/*************************************************************************
* Description:                                                           *
* The following is the microC code demonstrating use of the Altera       *
* University IP Cores                                                    *
**************************************************************************/

#include <stdio.h>
#include <math.h>
#include <string.h>
#include "sd/efs.h"
#include "sd/ls.h"
#include "includes.h"
#include "altera_up_avalon_audio.h"
#include "altera_up_avalon_audio_regs.h"
#include "altera_up_avalon_audio_and_video_config.h"
#include "system.h"
#include "../../../C2Wav/C2Wav.h"
#include "../../../C2Wav/make_wav.h"


/* Definition of Task Stacks and priorities */
#define     AUDIO_DATA_TASK_STACKSIZE   2048
#define     AUDIO_DATA_TASK_PRIORITY    1
OS_STK      audio_data_task_stk[AUDIO_DATA_TASK_STACKSIZE];
OS_EVENT *AudioFIFOSem;

/* Other defines */
#define     BUFFER_SIZE    4


void AudioISR(void *context, unsigned int id);
int ConfigureAudioFIFOInterrupt(alt_up_audio_dev* audio_dev);
void readSDCard(int index);

/* Handle audio data movement */
void audio_data_task(void* pdata)
{
	printf("Beginning\n");

    alt_up_audio_dev * audio_dev;
    alt_up_av_config_dev * audio_config_dev;
    unsigned int *SynthesizerBase = (unsigned int *) 0x1109074;

    unsigned int l_buf[BUFFER_SIZE];
    double SAMPLING_RATE = 44100, time = 0.0;
    unsigned int wave;
    int testTone = 56, byte;
    int i = 0, j = 0, returnValue[2];
    int writeSizeL = BUFFER_SIZE;

    /* Open Devices */
    audio_dev = alt_up_audio_open_dev ("/dev/audio_0");
    if ( audio_dev == NULL)
        printf("Error: could not open audio device \n");
    else
        printf("Opened audio device \n");

    audio_config_dev = alt_up_av_config_open_dev("/dev/audio_and_video_config_0");
    if ( audio_config_dev == NULL)
        printf("Error: could not open audio config device \n");
    else
        printf("Opened audio config device \n");

    /* Configure WM8731 */
    audio_config_dev = alt_up_av_config_open_dev(AUDIO_AND_VIDEO_CONFIG_0_NAME);
    //alt_up_audio_reset_audio_core(audio_dev);
    returnValue[0] = alt_up_av_config_reset(audio_config_dev);

    /* Write to configuration registers in the audio codec; see datasheet for what these values mean */
    /*
    alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x0, 0x17);
    alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x1, 0x17);
    alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x2, 0x68);
    alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x3, 0x68);
    alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x4, 0x1A);
    alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x5, 0x06);
    alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x6, 0x00);
    alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x7, 0x3E);
    alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x9, 0x01);*/

    returnValue[0] = alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x0, 0x17);
    returnValue[0] = alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x1, 0x17);
    returnValue[0] = alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x2, 0x7D);
    returnValue[0] = alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x3, 0x7D);
    returnValue[0] = alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x4, 0xD2);
    returnValue[0] = alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x5, 0x0C);
    returnValue[0] = alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x6, 0x00);
    returnValue[0] = alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x7, 0x0D);
    returnValue[0] = alt_up_av_config_write_audio_cfg_register(audio_config_dev, 0x9, 0x01);
    printf("AV configured \n");

    alt_up_audio_reset_audio_core(audio_dev);
    alt_up_av_config_reset(audio_config_dev);

    if (ConfigureAudioFIFOInterrupt(audio_dev) == -1)
    {
        printf("Error: Could not initialize audio interrupts\n");
        OSTaskDel(OS_PRIO_SELF);
        return;
    }

    //main2();


    printf("Starting\n");

    //main loop
    while(1) {
            //read the data from the left buffer
            //writeSizeL = alt_up_audio_read_fifo(audio_dev, l_buf, BUFFER_SIZE, ALT_UP_AUDIO_LEFT);

            //shift values to a proper base value
            for (i = 0; i < writeSizeL; i = i+1)
            {
            	//if(j<20000){
            	//case(0)
            	wave = ((int)(3200000*sin(2.0*M_PI*2400*time/SAMPLING_RATE)));
            	l_buf[i] = wave;
            	/*l_buf[i] = 0;
            	while (wave > 0) {
            		byte = wave & 0xFF;
            		l_buf[i] <<= 8;
            		l_buf[i] += byte;// + (100000*(j++))%2000000;//+3388608*sin(.1*(double)j++);//(2000000 + 1000*j++%2000000);
            		wave >>= 8;
            	}*/
            	time += 1.0;
            }

            //write data to the L and R buffers; R buffer will receive a copy of L buffer data
            alt_up_audio_write_fifo (audio_dev, l_buf, writeSizeL, ALT_UP_AUDIO_RIGHT);
            alt_up_audio_write_fifo (audio_dev, l_buf, writeSizeL, ALT_UP_AUDIO_LEFT);

            /*if(j++%(32768/2) == 0)
            	printf("data written:%i\n buffer[0]:%i\n", l_buf[0], writeSizeL);*/

    }

}


/* main task*/
int main(int argc, char ** argv, char ** env)
{

    OSTaskCreateExt(audio_data_task,
                  NULL,
                  (void *)&audio_data_task_stk[AUDIO_DATA_TASK_STACKSIZE-1],
                  AUDIO_DATA_TASK_PRIORITY,
                  AUDIO_DATA_TASK_PRIORITY,
                  audio_data_task_stk,
                  AUDIO_DATA_TASK_STACKSIZE,
                  NULL,
                  0);

    OSStart();
    return 0;
}

void AudioISR(void *context, unsigned int id)
{
    static INT8U err_flag = OS_NO_ERR;

    alt_up_audio_dev* audio_dev = (alt_up_audio_dev*)context;

    // Grab the semaphore value so we can maintain a binary semaphore
    OS_SEM_DATA semData;
    err_flag = OSSemQuery(AudioFIFOSem, &semData);
    if (err_flag != OS_NO_ERR)
    {
        return;
    }

    // Post the semaphore so that the audio task can continue if it's waiting on it
    if (alt_up_audio_write_interrupt_pending(audio_dev) && semData.OSCnt == 0)
    {
        err_flag = OSSemPost(AudioFIFOSem);
        if (err_flag != OS_NO_ERR)
        {
            return;
        }
    }

    // reset the interrupt
    alt_up_audio_disable_write_interrupt(audio_dev);
}

int ConfigureAudioFIFOInterrupt(alt_up_audio_dev* audio_dev)
{
    // Create the semaphore we'll post in the ISR, and pend on in the audio task
    AudioFIFOSem = OSSemCreate(0);
    if (AudioFIFOSem == NULL) return -1;

    // setup interrupts on the audio FIFO
    alt_up_audio_enable_write_interrupt(audio_dev);
    alt_irq_register (AUDIO_0_IRQ, (void*)audio_dev, (void*)AudioISR);

    return 0;
}
/*
void readSDCard(int index){
	int *command_argument_register = ((int *)(0x0000122C));
	short int *command_register = ((short int *)(0x00001230));
	short int *aux_status_register = ((short int *)(0x00001234));
	short int status;
	/* Wait for the SD Card to be connected to the SD Card Port. /
	do {
	status = (short int) IORD_16DIRECT(aux_status_register, 0);
	} while ((status & 0x02) == 0);
	/* Read 11th sector on the card /
	IOWR_32DIRECT(command_argument_register, 0, (index) * 512);
	IOWR_16DIRECT(command_register, 0, READ_BLOCK);
	/* Wait until the operation completes. /
	do {
	status = (short int) IORD_16DIRECT(aux_status_register, 0);
	} while ((status & 0x04)!=0);
}*/



int main2(void)
{
    // Create EFSL containers
    EmbeddedFileSystem efsl;

    // Initialises the filesystem on the SD card, if the filesystem does not
    // init properly then it displays an error message.
    printf("Attempting to init filesystem");
    volatile int ret = efs_init(&efsl, "/dev/spi_0");

    // Initialize efsl
    if(ret != 0)
    {
	printf("...could not initialize filesystem.\n");
	main2();
	return(1);
    }
    else
	printf("...success!\n");

    char fileName[LIST_MAXLENFILENAME] = {"openingToCanonInD"};
    File readFile;

    // You could do some scanning of the file system here using the UNIX-like
    // API functions such as "ls_openDir(...)" and "ls_getNext(...). Reference
    // the included PDF for the documentation to do such a thing. This example
    // simply shows reading a file with a known filename.

    // Open the test file
    printf("\nAttempting to open file: \"%s\"\n", fileName);

    if (file_fopen(&readFile, &efsl.myFs, fileName, 'r') != 0)
    {
	printf("Error:\tCould not open file\n");
	return(1);
    }
    else
    {
	printf("Reading file...\n");
    }

    // Create a memory buffer to read the file into
    euint8 *fileBuffer = malloc(readFile.FileSize * sizeof(euint8));
    if (!fileBuffer)
    {
	printf("malloc failed!\n");
	return(1);
    }

    // Read all the file's contents into the buffer. See the file_fread(...) function
    // for the ability to read chunks of the file at a time, which is desirable for
    // larger files.
    unsigned int bytesRead = file_read(&readFile, readFile.FileSize, fileBuffer);

    printf("%u bytes read from the file\n", bytesRead);

    // Close the file
    if (file_fclose(&readFile) != 0)
    {
	printf("Error:\tCould not close file properly\n");
	return(1);
    }

    // Print out the contents
    printf("\nFile contents (in hex):\n");
    int j;
    for (j = 0; j < bytesRead; ++j)
    {
	printf(" 0x%02X", fileBuffer[j]);
    }

    // Free the file buffer memory
    free(fileBuffer);

    // Unmount the file system
    fs_umount(&efsl.myFs);

    return(0);
}
/*
int main3(void)
{
    // Create EFSL containers

    // Initialises the filesystem on the SD card, if the filesystem does not
    // init properly then it displays an error message.

    // Initialize efsl

    char fileName[LIST_MAXLENFILENAME] = {"sample1.wav"};
    File readFile;

    // You could do some scanning of the file system here using the UNIX-like
    // API functions such as "ls_openDir(...)" and "ls_getNext(...). Reference
    // the included PDF for the documentation to do such a thing. This example
    // simply shows reading a file with a known filename.

    // Open the test file
    printf("\nAttempting to open file: \"%s\"\n", fileName);
    int fileLocation = fopen(&fileName, "euint8 *");
    if (fileLocation == 0)
    {
	printf("Error:\tCould not open file\n");
	return(1);
    }
    else
    {
	printf("Reading file...\n");
    }

    // Create a memory buffer to read the file into
    euint8 *fileBuffer = malloc(readFile.FileSize * sizeof(euint8));
    if (!fileBuffer)
    {
	printf("malloc failed!\n");
	return(1);
    }

    // Read all the file's contents into the buffer. See the file_fread(...) function
    // for the ability to read chunks of the file at a time, which is desirable for
    // larger files.
    unsigned int bytesRead = file_read(&readFile, readFile.FileSize, fileBuffer);

    printf("%u bytes read from the file\n", bytesRead);

    // Close the file
    if (file_fclose(&readFile) != 0)
    {
	printf("Error:\tCould not close file properly\n");
	return(1);
    }

    // Print out the contents
    printf("\nFile contents (in hex):\n");
    int j;
    for (j = 0; j < bytesRead; ++j)
    {
	printf(" 0x%02X", fileBuffer[j]);
    }

    // Free the file buffer memory
    free(fileBuffer);

    // Unmount the file system
    fs_umount(&efsl.myFs);

    return(0);
}*/
