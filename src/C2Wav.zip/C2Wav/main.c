#include "../song_structs.h"
#include "C2Wav.h"
#include "make_wav.h"
#include <math.h>

Track generateRandomTrack(int ID, int volume);

int main(int argc, char ** argv){
	Song song;
	song.tunes[0] = generateRandomTrack(0,128);
	song.song_id = 0;
	song.tempo = 60;

	C2Wav(song);
}

Track generateRandomTrack(int ID, int volume){
	Track newTrack;	Note newNote;
	int i = 0, j = 0;
	Note nullNote;
	nullNote.tone = '\0';
	newTrack.instrument_id = (ID+rand());//INSTRUMENT_TYPES%INSTRUMENT_NUMBER;
	Song tempSong;
	//these first two notes may cause the song to always get a score of 0

	while(j<MAX_NOTES){
		newNote.pause_time = 16*rand(); 
		newNote.hold_time = 2*rand();  
		if((j+newNote.hold_time)>MAX_NOTES){
			newNote.hold_time = MAX_NOTES-j;
		}
		newNote.tone = NUMBER_OF_TONES * rand();
		newTrack.channel[i++] = newNote;
		newTrack.volume = volume;
		j += newNote.hold_time;
	}
	newTrack.channel[i] = nullNote;
	return newTrack;
}
