#include "../song_structs.h"
#include "C2Wav.h"
#include "make_wav.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

Track generateRandomTrack(int ID, int volume);

int main(int argc, char ** argv){
	Song song;
	song.tunes[0] = generateRandomTrack(0,128);
	song.tunes[1] = generateRandomTrack(0,128);
	song.tunes[2] = generateRandomTrack(0,128);
	song.song_id = 0;
	song.tempo = 60;
	song.track_num = 3;

	C2Wav(song);
}

Track generateRandomTrack(int ID, int volume){
	Track newTrack;	Note newNote;
	int i = 0, j = 0;
	time_t t;
	srand((unsigned) time(&t));
//	printf("before id\n");
	newTrack.instrument_id = (rand()%(ID+1));//INSTRUMENT_TYPES%INSTRUMENT_NUMBER;
//	printf("after id\n");
	Song tempSong;
	newTrack.volume = volume;
	//these first two notes may cause the song to always get a score of 0

	while(j < MAX_NOTES){
		newNote.pause_time = rand()%2; 

		/*switch(ID){
			case(0):
				newNote.tone = (84-i)%96;
				newNote.hold_time = 2+i/3; 
				break;
			case(1):
				newNote.tone = (20+i)%96;
				newNote.hold_time = 6-(i/2%4); 
				break;
			case(2):
				newNote.tone = (18+i*i/10-2*i)%48;
				newNote.hold_time = 4; 
				break;
		}*/
		newNote.tone = 32;
		newNote.hold_time = 16;

//		printf("hold_time: %i\n", newNote.hold_time);
		if((j+newNote.hold_time)>MAX_NOTES){
			newNote.hold_time = MAX_NOTES-j;
		}
		//newNote.tone = rand()%NUMBER_OF_TONES;
		newTrack.channel[i++] = newNote;
		j += newNote.hold_time;
		printf("%i: %i\n", i, newNote.tone);
	}
	newTrack.track_length = i;
//	printf("track length: %i\n", newTrack.track_length);;
	return newTrack;
}
