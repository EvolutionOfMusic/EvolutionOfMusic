
#ifndef C2Wav_h
#define C2Wav_h

#include <stdio.h>
#include <math.h>
#include "../frequencies.h"
#include "../song_structs.h"
#include "make_wav.h"

void C2Wav(Song song);

#endif
