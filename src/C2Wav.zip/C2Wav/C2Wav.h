#include <stdio.h>
#include <math.h>
#include "../frequencies.h"
#include "../song_structs.h"
#include "make_wav.h"


void C2Wav(Song song){
	double SAMPLING_RATE = 8192, j[song.track_num];
	double SAMPLING_PERIOD  = song.tempo/60/SAMPLING_RATE;
	int i = 1, k, m[song.track_num], maxLength = 0;
	char title[38]; 
	sprintf(title, "main_py_samples_generation_%i", song.song_id);
	for(i = 0; i < song.track_num; i++){
		j[i] =  0;
		if(maxLength < song.tunes[i].track_length)
			maxLength = song.tunes[i].track_length;
	}

    int songArray[(int)ceil(maxLength*SAMPLING_RATE*NOTES_PER_MEASURE/song.tempo*60)];
	for(i = 0; i< maxLength; i++){
		songArray[i] = 0;
	}
	for(i = 0; i< maxLength; i++){
		for(k = 0; k < song.track_num; k++){
			if(j[k] > song.tunes[i].channel[m[k]].hold_time){
				j[k] = j[k] - floor(j[k]);
				m[k] += 1;
			} else{
				j[k] += SAMPLING_PERIOD;
			}
			
            songArray[i] += .9*sin(2*M_PI*frequencies[song.tunes[i].channel[m[k]].tone]*j[k]);
        }
		songArray[i]/song.track_num;
    }
	make_wav(title, maxLength, songArray, SAMPLING_RATE);	
}
